# Tweet

ID: 2064335057100198307
Author: 阿西_出海（2.0版）
Handle: @imaxichuhai
Date: 2026-06-09T03:58:51.000Z

URL:
https://x.com/imaxichuhai/status/2064335057100198307

---

AI 编程圈最近又火了一个开源工具—CodeGraph

github上狂揽4.5w star

它是为 AI 编程agent做的代码知识图谱工具，把函数定义、符号调用关系和依赖链整理成结构化图谱。

AI 写代码不用再反复翻文件，直接查图谱定位就行。

官方基准测试结构：在 4000 +文件的大型项目中，检索次数从 52 次降到 3 次，效率提升 17 倍

兼容 Claude Code、Cursor、Codex等主流 AI 助手，本地运行，数据不出本机。

朋友找我帮忙做一个电商库存后台，功能挺复杂的，高并发下单、库存扣减、防超卖，前后台都要有。

最近听说@StepFun_ai 出了新模型 Step 3.7 Flash，在 Agent 任务上表现不错，就想拿这个项目试试手。

---

## Media

- Video 1: blob:https://x.com/10d7843b-2a47-411b-9c9b-69d7fc6db361
- Video 2: blob:https://x.com/88fd8d1b-9197-4cf8-b184-c0c85fb84199

---

## Top Replies

### 梓欣寻固炮点击主页

Handle: @BrandieBel56268
Date: 2026-06-10T05:44:54.000Z
URL: https://x.com/BrandieBel56268/status/2064584569622327342

梓欣寻固炮点击主页
@BrandieBel56268
·
18分钟





5

### Kuang

Handle: @Kuang40064504
Date: 2026-06-10T02:21:01.000Z
URL: https://x.com/Kuang40064504/status/2064533262354325667

请问这和graphify有什么区别？

### 小白

Handle: @AlonaSheri19605
Date: 2026-06-10T00:54:32.000Z
URL: https://x.com/AlonaSheri19605/status/2064511498945454528

感觉发展都太快了，有点不适应了，每天都有新东西出现，害，搞的人都焦虑了

### 阿台BlueBird

Handle: @QT9277
Date: 2026-06-09T19:57:02.000Z
URL: https://x.com/QT9277/status/2064436627691524462

CodeGraph革命性提升AI编程效率，本地安全又高效。
