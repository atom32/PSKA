# Tweet

ID: 2064233751929053198
Author: 高军
Handle: @GoJun315
Date: 2026-06-09T06:30:52.000Z

URL:
https://x.com/GoJun315/status/2064233751929053198

---

一位 16 岁开发者，开源了一个无头浏览器引擎，专为爬虫和 AI Agent 自动化设计。

项目名叫 Obscura，使用 Rust 构建，已狂揽 14600+ GitHub Star。

与 headless Chrome 对比优势明显：

- 内存占用：30MB vs Chrome 的 200MB+，差距 7 倍以上
- 页面加载：85ms vs Chrome 的 500ms 左右
- 启动速度：瞬间启动 vs Chrome 的 2 秒
- 二进制体积：70MB vs Chrome 的 300MB+
- 内置反检测：自动绕过指纹识别和 tracker 屏蔽，Chrome 完全没有

GitHub：
https://
github.com/h4ckf0r0day/ob
scura
…

而且兼容 Puppeteer 和 Playwright 协议，老项目改一行代码就能直接换上。

另外还可以接入到 Claude Code、Codex 等 AI 工具，让 Agent 拥有真正操作浏览器能力。

适合做爬虫、数据采集、或者想给 AI Agent 接互联网能力的开发者。

---

## Media

- Image 1: media/image_01.jpg

---

## Top Replies

### 码上盈｜AI

Handle: @InnaLyceyum
Date: 2026-06-09T12:13:58.000Z
URL: https://x.com/InnaLyceyum/status/2064320093702762990

16岁就能整出这个 30MB干掉Chrome七倍 我到现在还在被内存占用支配

### Kristin Chapman

Handle: @KristinC99029
Date: 2026-06-10T02:46:35.000Z
URL: https://x.com/KristinC99029/status/2064539695351046159

⋆ꦿ꙳༘ Respect silence respect boundaries. ꙳⛬ꦿ༘⋆

### Abby Pittmon

Handle: @APittmon69138
Date: 2026-06-10T02:48:27.000Z
URL: https://x.com/APittmon69138/status/2064540164823638059

⋆༺꙳ꕤꦿ༘ Life becomes calm when you surrender. ꦿ꙳✧꙳༻꙳

### @clerk

Handle: @clerk
Date: 
URL: https://x.com/clerk/status/2060132972486131878/analytics

We shipped a CLI because clicking through dashboards isn't shipping. 

clerk init

Start free

### Charlene Southard

Handle: @CharleneSo57567
Date: 2026-06-09T16:07:00.000Z
URL: https://x.com/CharleneSo57567/status/2064378741069881439

〱ꚨꩩꪀꩀꩮ꫻ You don’t need many people, just genuine ones ꫼ꨤꨭꩰꩱꩲ〲

### Toya Sedillo

Handle: @SedilloToy45903
Date: 2026-06-09T16:06:54.000Z
URL: https://x.com/SedilloToy45903/status/2064378715719565637

𖣂ꪮꪯꪰꪮꪯ Live in the moment, not past regret ꪱꪲꪳꪆꪇꪈ𖣃

### llly

Handle: @lllyfeng
Date: 2026-06-09T13:02:11.000Z
URL: https://x.com/lllyfeng/status/2064332230508646710

不错！收藏了

### xboxbin

Handle: @xboxbin666
Date: 2026-06-10T01:21:52.000Z
URL: https://x.com/xboxbin666/status/2064518377666981892

牛逼

### 梓欣寻固炮点击主页

Handle: @BrandieBel56268
Date: 2026-06-10T05:44:54.000Z
URL: https://x.com/BrandieBel56268/status/2064584569605480484

梓欣寻固炮点击主页
@BrandieBel56268
·
18分钟





4

### 依诗寻固炮点击主页

Handle: @RosauraMcf43237
Date: 2026-06-10T05:12:24.000Z
URL: https://x.com/RosauraMcf43237/status/2064576393585824211

依诗寻固炮点击主页
@RosauraMcf43237
·
51分钟





15

### 依怡寻固炮点击主页

Handle: @CousineauD30023
Date: 2026-06-10T04:39:42.000Z
URL: https://x.com/CousineauD30023/status/2064568163736465823

依怡寻固炮点击主页
@CousineauD30023
·
1小时





28
